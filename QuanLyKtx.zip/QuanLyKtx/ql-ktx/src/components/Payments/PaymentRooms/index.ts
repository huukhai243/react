export { default } from './PaymentRooms'
