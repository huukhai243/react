export const StoryStorePath = '/stories'
