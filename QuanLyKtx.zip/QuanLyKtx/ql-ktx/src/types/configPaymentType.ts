export interface ConfigPayment {
  electric: number
  water: number
  parking_bike: number
  parking_moto: number
}
