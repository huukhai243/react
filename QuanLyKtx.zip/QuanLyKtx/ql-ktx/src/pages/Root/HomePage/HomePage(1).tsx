const HomePage = () => {
  return (
    <div className="z-10 rounded-lg w-full h-full text-sm lg:flex">
      đây là trang chủ
    </div>
  )
}

export default HomePage
