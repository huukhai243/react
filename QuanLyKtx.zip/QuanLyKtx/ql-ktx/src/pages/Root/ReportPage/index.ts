export { default } from './ReportPage'
