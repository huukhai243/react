export { default } from './RegistrationPage'
