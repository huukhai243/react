const NotFoundPage = () => {
  return <div>404 NotFound</div>
}

export default NotFoundPage
