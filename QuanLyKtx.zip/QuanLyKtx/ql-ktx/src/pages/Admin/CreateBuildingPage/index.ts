export { default } from './CreateBuildingPage'
