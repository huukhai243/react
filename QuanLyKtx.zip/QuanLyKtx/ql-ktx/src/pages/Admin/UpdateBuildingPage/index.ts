export { default } from './UpdateBuildingPage'
