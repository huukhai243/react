export { default } from './PaymentsPage'
