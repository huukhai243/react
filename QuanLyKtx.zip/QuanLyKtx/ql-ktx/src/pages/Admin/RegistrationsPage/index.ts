export { default } from './RegistrationsPage'
