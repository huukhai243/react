export { default } from './StatisticPage'
