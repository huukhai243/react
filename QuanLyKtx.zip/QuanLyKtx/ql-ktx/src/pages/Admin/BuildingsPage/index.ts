export { default } from './BuildingsPage'
