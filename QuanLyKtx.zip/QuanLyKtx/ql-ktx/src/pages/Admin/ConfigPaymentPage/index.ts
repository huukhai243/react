export { default } from './ConfigPaymentPage'
