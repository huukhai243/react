export { default } from './RoomsPage'
