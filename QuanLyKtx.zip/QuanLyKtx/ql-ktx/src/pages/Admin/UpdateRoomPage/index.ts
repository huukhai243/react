export { default } from './UpdateRoomPage'
