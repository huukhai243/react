export { default } from './RegistrationParkingsPage'
