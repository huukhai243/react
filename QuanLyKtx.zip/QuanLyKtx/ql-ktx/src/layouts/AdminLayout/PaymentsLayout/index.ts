export { default } from './PaymentsLayout'
