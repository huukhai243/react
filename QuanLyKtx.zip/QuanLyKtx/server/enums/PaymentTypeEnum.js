const PaymentTypeEnum = {
    UN_ACTIVE: "unactive",
    ACTIVE: "active",
};

module.exports = PaymentTypeEnum;
