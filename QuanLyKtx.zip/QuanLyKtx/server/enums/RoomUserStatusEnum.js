const RoomUserStatusEnum = {
    IN: 1,
    OUT: 2,
};

module.exports = RoomUserStatusEnum;
