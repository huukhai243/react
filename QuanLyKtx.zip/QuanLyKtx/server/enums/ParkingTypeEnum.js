const ParkingTypeEnum = {
  BIKE: "bike",
  MOTO: "moto",
};

module.exports = ParkingTypeEnum;
