const UserTypeEnum = {
  SUP_ADMIN: "sup_admin",
  ADMIN: "admin",
  STUDENT: "user",
};

module.exports = UserTypeEnum;
