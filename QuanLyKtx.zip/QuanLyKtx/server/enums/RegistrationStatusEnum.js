const RegistrationStatusEnum = {
    WAIT: 0,
    ACTIVE: 1,
    UN_ACTIVE: 2,
};

module.exports = RegistrationStatusEnum;
