const bcrypt = require("bcrypt");
const saltRounds = 10;

console.log(makePass(123));
